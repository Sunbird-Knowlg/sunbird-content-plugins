/**
 * Plugin to create MCQ question
 * @class org.ekstep.questionunitmcq:mtfQuestionFormController
 * Jagadish P<jagadish.pujari@tarento.com>
 */
angular.module('createquestionapp', [])
  .controller('mtfQuestionFormController', ['$scope', '$rootScope', function($scope, $rootScope) {

    $scope.formVaild = false;
    $scope.mcqConfiguartion = {
      'questionConfig': {
        'isText': true,
        'isImage': true,
        'isAudio': true,
        'isHint': false
      },
      'optionsConfig': [{
          'isText': true,
          'isImage': true,
          'isAudio': true,
          'isHint': false
        },
        {
          'isText': true,
          'isImage': true,
          'isAudio': true,
          'isHint': false
        }
      ]
    };
    $scope.mtfFormData = {
      'question': {
        'text': '',
        'image': '',
        'audio': '',
        'hint': ''
      },
      'option': {
        'optionsLHS': [{
            'text': '',
            'image': '',
            'audio': '',
            'hint': '',
            'index': 1
          },
          {
            'text': '',
            'image': '',
            'audio': '',
            'hint': '',
            'index': 2
          },
          {
            'text': '',
            'image': '',
            'audio': '',
            'hint': '',
            'index': 3
          }
        ],
        'optionsRHS': [{
            'text': '',
            'image': '',
            'audio': '',
            'hint': '',
            'mapIndex': 1,
            'multiple': []
          },
          {
            'text': '',
            'image': '',
            'audio': '',
            'hint': '',
            'mapIndex': 2,
            'multiple': []
          },
          {
            'text': '',
            'image': '',
            'audio': '',
            'hint': '',
            'mapIndex': 3,
            'multiple': []
          }
        ],
        'distractor': []
      }
    };
    $scope.oHint = [];
    $scope.questionMedia = {};
    $scope.optionsMedia = {
      'image': [],
      'audio': []
    };
    $scope.mtfFormData.media = [];
    $scope.editMedia = [];
    $scope.init = function() {
      $('.menu .item').tab();
      if (!ecEditor._.isUndefined($scope.questionEditData)) {
        var data = $scope.questionEditData.data;
        $scope.mtfFormData.question = data.question;
        $scope.mtfFormData.options = data.options;
        $scope.editMedia = $scope.questionEditData.media;
        //$scope.mtfFormData.media = $scope.questionEditData.media;
        if (data.length > 3) {
          for (var j = 3; j < data.length; j++) {
            $scope.mtfFormData.options.push({
              'text': '',
              'image': '',
              'audio': '',
              'isCorrect': false
            });
            //$scope.mcqConfiguartion.optionsConfig.push({'isText':true,'isImage':true,'isAudio':true,'isHint':true});
            $scope.$safeApply();
          }
        }
        if ($scope.mtfFormData.options.length < 3) {
          $scope.mtfFormData.options.splice(3, 1);
        }
      }

      $scope.$parent.$on('question:form:val', function(event) {
        if ($scope.formValidation()) {
          $scope.$emit('question:form:valid', $scope.mtfFormData);
        } else {
          $scope.$emit('question:form:inValid', $scope.mtfFormData);
        }
      })
    }

    $scope.addAnswerField = function() {
      var optionLHS = {
        'text': '',
        'image': '',
        'audio': '',
        'hint': '',
        'index': 1
      };
      var optionRHS = {
        'text': '',
        'image': '',
        'audio': '',
        'hint': '',
        'mapIndex': 2,
        'multiple': []
      };
      if ($scope.mtfFormData.option.optionsLHS.length < 4) {
        $scope.mtfFormData.option.optionsLHS.push(optionLHS);
        $scope.mtfFormData.option.optionsRHS.push(optionRHS);
      }
    }
    $scope.addDistractor = function() {
      if ($scope.mtfFormData.option.distractor.length < 2) {
        var distract = {
          'text': '',
          'image': '',
          'audio': '',
          'hint': ''
        };
        $scope.mtfFormData.option.distractor.push(distract);
      }

    }
    $scope.removeDistractor = function(id) {
      $scope.mtfFormData.option.distractor.splice(id, 1);
    }

    $scope.formValidation = function() {
      console.log($scope.mtfFormData);
      var opSel = false;
      var valid = false;
      var formValid = $scope.mtfForm.$valid;
      $scope.submitted = true;
      if (!_.isUndefined($scope.selectedOption)) {
        _.each($scope.mtfFormData.options, function(k, v) {
          $scope.mtfFormData.options[v].isCorrect = false;
        });
        valid = true;
        $scope.mtfFormData.options[$scope.selectedOption].isCorrect = true;
      } else {
        _.each($scope.mtfFormData.options, function(k, v) {
          if (k.isCorrect) {
            valid = true;
          }
        });
      }
      if (valid) {
        opSel = true;
        $scope.selLbl = 'success';
      } else {
        opSel = false;
        $scope.selLbl = 'error';
      }
      //$scope.mtfFormData.media = [];
      var tempArray = [];
      _.isEmpty($scope.questionMedia.image) ? 0 : tempArray.push($scope.questionMedia.image);
      _.isEmpty($scope.questionMedia.audio) ? 0 : tempArray.push($scope.questionMedia.audio);
      _.each($scope.optionsMedia.image, function(key, val) {
        tempArray.push(key);
      });
      _.each($scope.optionsMedia.audio, function(key, val) {
        tempArray.push(key);
      });
      var temp = tempArray.filter(function(element) {
        return element !== undefined;
      });
      $scope.editMedia = _.isEmpty(temp) ? 0 : _.union($scope.editMedia, temp);
      $scope.mtfFormData.media = _.isEmpty($scope.editMedia[0]) ? temp : $scope.editMedia;
      console.log("Form data", $scope.mtfFormData);
      return (formValid && opSel) ? true : false;
    }

    $scope.deletePair = function(id) {
      // if ($scope.mtfFormData.option.optionsLHS.length > 3 && $scope.mtfFormData.option.optionsRHS.length > 3) {
        $scope.mtfFormData.option.optionsLHS.splice(id, 1);
         $scope.mtfFormData.option.optionsRHS.splice(id, 1);
       //}
    }

    $scope.addImage = function(id, type) {
      ecEditor.dispatchEvent('org.ekstep.assetbrowser:show', {
        type: 'image',
        search_filter: {}, // All composite keys except mediaType
        callback: function(data) {
          var tempImage = {
            "id": Math.floor(Math.random() * 1000000000), // Unique identifier
            "src": org.ekstep.contenteditor.mediaManager.getMediaOriginURL(data.assetMedia.src), // Media URL
            "assetId": data.assetMedia.id, // Asset identifier
            "type": "image", // Type of asset (image, audio, etc)
            "preload": false // true or false
          };
          //$scope.mtfFormData.media.push(tempImage);
          if (id == 'q') {
            $scope.mtfFormData.question.image = org.ekstep.contenteditor.mediaManager.getMediaOriginURL(data.assetMedia.src);
            $scope.questionMedia.image = tempImage;
          } else if (type == 'LHS') {
            $scope.mtfFormData.option.optionsLHS[id].image = org.ekstep.contenteditor.mediaManager.getMediaOriginURL(data.assetMedia.src);
            $scope.optionsMedia.image[id] = tempImage;
          }
          else if(type=='RHS'){
             $scope.mtfFormData.option.optionsRHS[id].image = org.ekstep.contenteditor.mediaManager.getMediaOriginURL(data.assetMedia.src);
            $scope.optionsMedia.image[id] = tempImage;
          }
          else if(type=='dist'){
             $scope.mtfFormData.option.distractor[id].image = org.ekstep.contenteditor.mediaManager.getMediaOriginURL(data.assetMedia.src);
            $scope.optionsMedia.image[id] = tempImage;
          }
        }
      });
    }

    $scope.addAudio = function(id,type) {
      ecEditor.dispatchEvent('org.ekstep.assetbrowser:show', {
        type: 'audio',
        search_filter: {}, // All composite keys except mediaType
        callback: function(data) {
          var tempAudio = {
            "id": Math.floor(Math.random() * 1000000000), // Unique identifier
            "src": org.ekstep.contenteditor.mediaManager.getMediaOriginURL(data.assetMedia.src), // Media URL
            "assetId": data.assetMedia.id, // Asset identifier
            "type": "audio", // Type of asset (image, audio, etc)
            "preload": false // true or false
          };
          if (id == 'q') {
            $scope.mtfFormData.question.audio = org.ekstep.contenteditor.mediaManager.getMediaOriginURL(data.assetMedia.src);
            $scope.questionMedia.audio = tempAudio;
          } else if (type == 'LHS'){
            $scope.mtfFormData.option.optionsLHS[id].audio = org.ekstep.contenteditor.mediaManager.getMediaOriginURL(data.assetMedia.src);
            $scope.optionsMedia.audio[id] = tempAudio;
          }else if (type == 'RHS'){
            $scope.mtfFormData.option.optionsRHS[id].audio = org.ekstep.contenteditor.mediaManager.getMediaOriginURL(data.assetMedia.src);
            $scope.optionsMedia.audio[id] = tempAudio;
          } else if(type=='dist'){
             $scope.mtfFormData.option.distractor[id].audio = org.ekstep.contenteditor.mediaManager.getMediaOriginURL(data.assetMedia.src);
            $scope.optionsMedia.audio[id] = tempAudio;
          }
        }
      });
    }

    $scope.addHint = function(id) {
      if (id == 'q') {
        $scope.qHint = true;
      } else {
        $scope.oHint[id] = true;
      }
    }

    $scope.deleteImage = function(id,type) {
      if (id == 'q') {
        $scope.mtfFormData.question.image = '';
        delete $scope.questionMedia.image;
      } else if(type=='LHS') {
         $scope.mtfFormData.option.optionsLHS[id].image = '';
        //$scope.optionsMedia.image.splice(id,1);
        delete $scope.optionsMedia.image[id];
      }
      else if(type=='RHS'){
         $scope.mtfFormData.option.optionsRHS[id].image = '';
        //$scope.optionsMedia.image.splice(id,1);
        delete $scope.optionsMedia.image[id];
      }
      else if(type='dist'){
         $scope.mtfFormData.option.distractor[id].image = '';
        //$scope.optionsMedia.image.splice(id,1);
        delete $scope.optionsMedia.image[id];
      }
    }

    $scope.deleteAudio = function(id,type) {
      if (id == 'q') {
        $scope.isPlayingQ = false;
        $scope.mtfFormData.question.audio = '';
        delete $scope.questionMedia.audio;
      } else if(type=='LHS') {
         $scope.mtfFormData.option.optionsLHS[id].audio = '';
        //$scope.optionsMedia.image.splice(id,1);
        delete $scope.optionsMedia.audio[id];
      }
      else if(type=='RHS'){
         $scope.mtfFormData.option.optionsRHS[id].audio = '';
        //$scope.optionsMedia.image.splice(id,1);
        delete $scope.optionsMedia.audio[id];
      }
    }

    $scope.deleteHint = function(id) {
      if (id == 'q') {
        $scope.qHint = false;
        $scope.mtfFormData.question.hint = '';
      } else {
        $scope.oHint[id] = false;
        $scope.mtfFormData.options[id].hint = '';
      }
    }

  }]);
//# sourceURL=horizontalMtf.js