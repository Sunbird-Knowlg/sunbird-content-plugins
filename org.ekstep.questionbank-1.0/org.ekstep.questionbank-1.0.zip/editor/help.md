**Question Set**

You can add question sets to your lesson to help a child practice a concept.

---

***Are you a developer?***

To get started visit <a href="https://community.ekstep.in/developers" target="_blank">EkStep Developer Community</a>
