'use strict';

describe('Question plugin: tests', function() {
    //TODO: Editor Test cases
});
